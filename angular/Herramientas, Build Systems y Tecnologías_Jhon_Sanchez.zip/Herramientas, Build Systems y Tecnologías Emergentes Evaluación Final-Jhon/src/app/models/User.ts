export class Usuario{
  constructor(private nombre: string, private contraseghnia: string){

  }
}
