import { PipeProductosPipe } from './pipe-productos.pipe';

describe('PipeProductosPipe', () => {
  it('create an instance', () => {
    const pipe = new PipeProductosPipe();
    expect(pipe).toBeTruthy();
  });
});
