

## Development server

Usar el comando `ng serve` para ejecutar el proyecto en modo desarrollo. Ir a `http://localhost:4200/` para abrir la aplicación.
